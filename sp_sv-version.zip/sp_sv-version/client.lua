local displayText = ""

RegisterNetEvent('displayVersion')
AddEventHandler('displayVersion', function(version)
    displayText = version
end)

Citizen.CreateThread(function()
    TriggerServerEvent('requestVersion')

    while true do
        Citizen.Wait(0)
        if displayText ~= "" then
            SetTextFont(0)
            SetTextProportional(1)
            SetTextScale(0.0, 0.3)
            SetTextColour(255, 255, 255, 255)
            SetTextDropShadow(0, 0, 0, 0, 255)
            SetTextEdge(1, 0, 0, 0, 255)
            SetTextDropShadow()
            SetTextOutline()
            SetTextEntry("STRING")
            AddTextComponentString(displayText)
            DrawText(0.005, 0.975)
        end
    end
end)
