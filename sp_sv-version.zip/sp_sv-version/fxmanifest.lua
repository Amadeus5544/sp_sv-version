fx_version 'cerulean'
games {'gta5'}

client_script 'client.lua'
server_script 'server.lua'
