local serverVersion = GetConvar("server_version", "N/A")

RegisterServerEvent('requestVersion')
AddEventHandler('requestVersion', function()
    local src = source
    TriggerClientEvent('displayVersion', src, serverVersion)
end)
